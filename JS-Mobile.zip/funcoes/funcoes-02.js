//DECLARAÇÃO OU CRIAÇÃO 
// function soma(n1, n2) {
//   if (typeof n1 === 'number' && typeof n2 === 'number') {
//     const res = n1 + n2;
//     alert('O resultado da soma é: ' + res)
//   } else {
//     alert('Por favor insira um valor válido!')
//   }
// }
// //INVOCAÇÃO OU CHAMAR 
// soma("queijo", 3)
// soma(10, 20)
// soma(50, 50)
// soma(-15, 32)

//CRIE UMA FUNÇÃO QUE RECEBA COMO PARAMETROS:
//NOME,ALTURA
//CHEQUE SE NOME É  DO TIPO  "STRING"
//CHEQUE SE ALTURA É DO TIPO "NUMBER"
//SE AMBAS FOREM VERDADEIRAS RETORNE A MENSAGEM "Olá, {NOME}! Você tem {ALTURA} de altura."

// const nome = "Janette"
// const altura = 1.65

function mensagem(nome, altura){
  if (typeof nome === 'string' && typeof altura === 'number') {
    alert("Olá, " + nome + "!  Você tem " + altura + "  de altura. ")
  }
    else {
      alert('Por favor insira um valor válido!')
    } 
  }
  
  mensagem("Clara" , 2.20)

 
  



































































