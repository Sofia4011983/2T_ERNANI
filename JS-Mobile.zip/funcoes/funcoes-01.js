/**FUNÇÕES: São blocos de código que podem ser reaproveitados 
 *Funções podem ou não ter nomes 
 *Podem ou não receber parametros
 */
//CRIAR OU RECEBER FUNÇÕES 
function dizOlá(nome) {
  //código 
  
  console.log("Olá" + nome)

  
}
//INVOCAR / CHAMAR FUNÇÕES 
dizOlá(' Clara')
dizOlá(' Ovaldo')
dizOlá(' Gemário')


function somaDoisNumeros(a, b) {
  const soma = a + b
  console.log(soma)
}
somaDoisNumeros(2, 3)


function multiplicacaoDoisNumeros(a, b) {
  const multiplicacao = a * b
  console.log(multiplicacao)
}
multiplicacaoDoisNumeros(2, 9)


function subtraçãoDoisNumeros(a, b) {
  const subtracao = a - b
  console.log(subtracao)
}
subtraçãoDoisNumeros(50, 10)


function divisaoDoisNumeros(a, b) {
  const divisao = a / b
  console.log(divisao)
}
divisaoDoisNumeros(20, 2)

