//FUNÇOES COM RETORNO 
//SÃO FUNÇÕES QUE PERMITEM RETER UM VALOR 
//PROCESSADO
//PARA USO POSTERIOR

const nome = 'laura'
function retornaDados() {
  //codigo com retorno
  return nome.toUpperCase()
}
const dados = retornaDados()
console.log(dados)

const armazenarDados = () => console.log Nome: ${ nome.value }

Idade: ${ idade.value }
CPF: ${ cpf.value })












