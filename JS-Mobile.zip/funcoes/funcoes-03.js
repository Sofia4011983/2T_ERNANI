
// function mensagem(nome, sobrenome) {
//   if (typeof nome === 'string' && typeof sobrenome === 'string') {
//     alert("Olá, " + nome + sobrenome + ".")
//   }
//   else {
//     alert('Por favor insira um valor válido!')
//   }
// }

// mensagem("Renato ", "Oliveira")





function N (N) {
  if (typeof N === 'number') {

    if ( N % 2 === 0) {
      alert("O número " + N + " é par.")
    }
    else {
      alert("O número " + N + " é ímpar.")
    }
    }
  
  else {
    alert('Por favor insira um valor válido!')
   }}

  N(550)
  N(997)
  N('Jabuticaba')




















