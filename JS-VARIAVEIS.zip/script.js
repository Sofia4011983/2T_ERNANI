/**
*DECLARAÇÃO DE VARIÁVEIS
* identificador: nome da variável
 valor: valor inicial da variável, 
 */

const nome = "Sofia"; //escopo global-mutável
const sobrenome = " Hanemann "; //escopo em bloco-mutável
const idade = 16; //escopo em bloco-imutável

//REATRIBUINDO VALORES 

//CONTATENAR OU JUNTAR VALORES
const dadosPessoais = nome + sobrenome + idade
const ano = 2024
const anoNascimento = 2007
const idadeAtual = ano - anoNascimento
const num = 24
const ehPar = num % 2 == 0 //PAR
const ehImpar = num % 2 == 1 //IMPAR
//IF SE-ELSE-SENÃOImparOu

//console.log(ParOuImpar)
//console.log(ImparOuPar)

//console.log( idadeAtual+ " anos")
if (ehPar) {
  console.log("o número é par")
} else {
  console.log("o número é impar")
}









/**CRIE UMA VARIAVEL PARA CADA SITUAÇÃO*/
//passatempo;
//cidade;
//precoDolar;
//animalEstimação;
//estaSolteiro=true;
//todosOsDados (contatenar)


//CONTATENAR OU JUNTAR VALORES
const passatempo = "ler";
const cidade = "Curitiba";
const precoDolar = "5,12";
const animalEstimação = "gato";
const estaSolteiro = true;

//console.log("Passa Tempo-" + passatempo + " Cidade-" + cidade + " Preço do Dolar-" + precoDolar + " Animal de Esimação-" + animalEstimação + " " + " Está solteira?" +
// estaSolteiro)





