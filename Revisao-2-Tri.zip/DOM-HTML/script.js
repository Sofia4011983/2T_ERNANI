

//OBJETIVO

/**
 * CRIAR VARIAVEIS E USA-LAS P MODIFCAR O DOM
 */


const titulo = document.getElementById("titulo");
const paragrafo = document.getElementById("paragrafo");


alert(titulo)

//minhas variaveis

const novoTitulo = "Título Modificado";
const novoParagrafo = "Paragrafo Modificado";

titulo.innerText = novoTitulo;
paragrafo.innerText = novoParagrafo;


//ARRAYS OU LISTA 
// ARRAYS SÃO ORGANIZADOS POR INDICES 
//() [] {} 



//console.log(roupa)
//console.log(roupas)
//console.log(roupas[3])
//roupas[20]= 'Brownie'
//console.log(roupas[20])//  undefined
//ITERAÇÃO: REPETIÇÃO ATÉ O ESGOTAMENTO...
//DE UM LOOP DE REPETIÇÃO (FOR)

const roupa = 'Camiseta'
const roupas = ['Camiseta', 'Calça', 'Bermuda', 'Meia']
//INDICES         0          1         2         3
const precos = [10, 20, 30, 40]
const idades = [1, 25, 65, 28]
const misto = ['Manga', '33', 'Camaro', 'Brawl', false]

for (var i = 0; i <= 3; i++) {
  //lógica
  console.log(roupas[i])
  //logica imprimindo os precos
}

for (var j = 0; j <= 3; j++) {
  //lógica
  console.log(precos[j])
  //logica imprimindo os precos
}








