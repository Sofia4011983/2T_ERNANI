//SELECIONAR COM QUERYSELECTOR()


const vermelho = document.querySelector('.vermelho');
//alert(vermelho)
const verde = document.querySelector('.verde');
const azul = document.querySelector('.azul');
const amarelo = document.querySelector('.amarelo');
const roxo = document.querySelector('.roxo');
const laranja = document.querySelector('.laranja');
const marrom = document.querySelector('.marrom');

const conteúdo = document.querySelector('.conteúdo');
const bigText = document.querySelector('h1');

vermelho.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#9d0202';
  bigText.style.color = 'white';
})
verde.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#71bc5c';
  bigText.style.color = 'white';
})
azul.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#0d75c5';
  bigText.style.color = 'white';
})
amarelo.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#d9b608';
  bigText.style.color = 'white';
})
roxo.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#811ed2';
  bigText.style.color = 'white';
})
laranja.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#f5740a';
  bigText.style.color = 'white';
})
marrom.addEventListener('click', function() {
  conteúdo.style.backgroundColor = '#9d6c0c';
  bigText.style.color = 'white';
})
