//SELEIONAR ELEMENTOS HTML

const color = document.querySelector('#color');

const range = document.querySelector('#range');

const box = document.querySelector('.box');

const valorCor = document.querySelector('.valor-cor');

//alert(color.value) //valor dentro do input color




//CRAR EVENTOS DE MANIPULAÇÃO
range.value = 0;

//EVENTO DE INPUT
range.addEventListener('input', function() {

  box.style.borderRadius = range.value + 'px';
})

color.addEventListener('input', function() {
  box.style.backgroundColor = color.value;
  valorCor.innerHTML = color.value;
  valorCor.style.color = "white"
})




