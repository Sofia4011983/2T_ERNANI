const btnAlternar = document.getElementById('btn-Alternar')
const imglampada = document.getElementById('lampada')
const baseUrl = "https://103ca315-a679-4185-bcb9-e1248bffbe87-00-3fe4au1957axr.picard.replit.dev/"

btnAlternar.addEventListener('click', function() {
  if (imglampada.src == baseUrl + 'lampada0.png') {
    imglampada.src = "lampada2.png"
  } else {
    imglampada.src = "lampada0.png"
  }


})