//VALORES DO HTML ESTÁTICO
const nome = document.getElementById('nome');

//VALORES DE VARIAVEIS

const Sobrenome = document.getElementById('sobrenome');
const Idade = document.getElementById('idade');
const Localdenascimento = document.getElementById('local de nascimento');
const Nomedamãe = document.getElementById('nome da mãe');
const Nomedopai = document.getElementById('nome do pai');
const CGM = document.getElementById('cgm');
const Email = document.getElementById('email');
//NOVOS VALOS ATRIBUIDOS DE FORMA DINÂMICA
nome.innerHTML = novoNome;